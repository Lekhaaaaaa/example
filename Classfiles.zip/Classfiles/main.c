#include <stdio.h>
#include <stdlib.h>


void createAndWriteToFile(int n) {

    int i;
    for (i=1;i<=n;i++){
        char filename[20];
        //creates new file
        sprintf(filename,"file%d.txt",i);

        //opens file in write mode
        FILE * file= fopen(filename,"w");

        if (file == NULL) {
        printf("Unable to create file %s\n",filename);
        return;
        }

        //prints content into the file
        fprintf(file,"pqr%d.dat",i);

        //close the file
        fclose(file);


    }
}


//Create a new file with the content from old file and store old filename as content into the new file
void createNewFileWithOldContent(int n) {
    int i;
    char srcFileName[20];
    char destFileName[20];

    for(i=1;i<=n;i++){
        sprintf(srcFileName,"file%d.txt", i);  //creates file
        FILE *srcFile = fopen(srcFileName, "r"); //opens file
        fscanf(srcFile, "%s", &destFileName); //scans file for content

        FILE *destFile = fopen(destFileName, "w"); //creates new file with the name from the old file
        fprintf(destFile, "%s ", srcFileName); //writes the name of old file in the new file
        fclose(srcFile); //close old file
        fclose(destFile); //close new file

    }
}

void displayFileContent(int n){

    int i;
    char srcFileName1[20];
    char srcFileName2[20];
    char content1[20];
    char content2[20];

    //Opens the file (file.txt) in read mode.Reads the content of file. Displays it. Closes the file.
    for (i=1;i<=n;i++){
        sprintf(srcFileName1,"file%d.txt", i);
        FILE *srcFile1 = fopen(srcFileName1, "r");
        fscanf(srcFile1, "%s", &content1);
        printf("Filename:%s\t Content:%s\n ",srcFileName1,content1);
        fclose(srcFile1);
    }
    printf("\n");


    //Opens the file (pqr.dat) in read mode.Reads the content of file. Displays it. Closes the file.
    for (i=1;i<=n;i++){
        sprintf(srcFileName2,"pqr%d.dat", i);
        FILE *srcFile2 = fopen(srcFileName2, "r");
        fscanf(srcFile2, "%s", &content2);
        printf("Filename:%s\t Content:%s\n ",srcFileName2,content2);
        fclose(srcFile2);
    }

}


int main() {
        //Creating and writing files
        createAndWriteToFile(5);

        //Create a new file with the content from old file and store old filename as content into the new file
        createNewFileWithOldContent(5);

        //Displays the content of the file
        displayFileContent(5);

    return 0;
}
